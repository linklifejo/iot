package kr.icia.service;

public interface LedService {
	public void register(String onOff);
}
