package kr.icia.mapper;

public interface LedMapper {
	public void insert(String onOff);
}
